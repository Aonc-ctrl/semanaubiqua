document.getElementById('save-dates').addEventListener('click', function() {
    const checkinDate = document.getElementById('checkin').value;
    const checkoutDate = document.getElementById('checkout').value;

    localStorage.setItem('checkinDate', checkinDate);
    localStorage.setItem('checkoutDate', checkoutDate);
    alert('Datas Salvas com Sucesso');
});

window.addEventListener('load', function() {
    const savedCheckin = localStorage.getItem('checkinDate');
    const savedCheckout = localStorage.getItem('checkoutDate'); 
    
    if (savedCheckin) {
        document.getElementById('checkin').value = savedCheckin;
    }
    if (savedCheckout) {
        document.getElementById('checkout').value = savedCheckout;
    }
});
